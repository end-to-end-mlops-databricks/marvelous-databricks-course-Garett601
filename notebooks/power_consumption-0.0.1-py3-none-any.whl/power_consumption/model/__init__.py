from .rf_model import ConsumptionModel

__all__ = ["ConsumptionModel"]
